package org.codehaus.mojo.cobertura.its;

/**
 * Hello world!
 *
 */
public class App 
{
    
    public boolean foo()
    {
        System.out.println( " hello toto, in english hello foo" );
        return true;
    }

}
